package com.ingenieraglobal.ecommerce.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ingenieraglobal.ecommerce.models.DetalleCarrito;

import java.util.List;
import java.util.Optional;


@Repository
public interface DetalleCarritoRepository extends JpaRepository<DetalleCarrito, Long>{
    List<DetalleCarrito> findByCarritoId(Long carritoId);
    Optional<DetalleCarrito>findByCarritoIdAndProductoId(Long carritoId, Long productoId);
    
    Optional<DetalleCarrito>findByIdAndCarritoId(Long id, Long carritoId);

    void deleteByCarritoId(Long carritoId);

    Optional<DetalleCarrito> findByCarritoIdAndPresentacionProductoId(Long carritoId, Long presentacionProductoId);

    
    
}
